import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
                
                
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();

        //List of destinations with images
        addDestinationNameAndPicture("1. London, England", new ImageIcon(getClass().getResource("/resources/London.jpg")));
        addDestinationNameAndPicture("2. Dublin, Ireland", new ImageIcon(getClass().getResource("/resources/Dublin.jpg")));
        addDestinationNameAndPicture("3. Las Vegas, Nevada, USA ", new ImageIcon(getClass().getResource("/resources/Las Vegas.jpg")));
        addDestinationNameAndPicture("4. Buenos Aires, Argentina", new ImageIcon(getClass().getResource("/resources/Buenos Aires.jpg")));
        addDestinationNameAndPicture("5. New York City, New York, USA", new ImageIcon(getClass().getResource("/resources/New York City.jpg")));
   
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setCellRenderer(renderer);

        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
        
        
        
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());
        
        

        return this;
    }
    
    //Drop down enhancement 
    public class DropDown {
        public static void main(String[] args) {
        	String[] optionsToChoose = {"London", "Dublin", "Las Vegas", "Buenos Aires", "New York City"};

            JFrame jFrame = new JFrame();

            JComboBox<String> jComboBox = new JComboBox<>(optionsToChoose);
            jComboBox.setBounds(80, 50, 140, 20);

            JButton jButton = new JButton("Done");
            jButton.setBounds(100, 100, 90, 20);

            JLabel jLabel = new JLabel();
            jLabel.setBounds(90, 100, 400, 100);

            jFrame.add(jButton);
            jFrame.add(jComboBox);
            jFrame.add(jLabel);
            
            jFrame.setLayout(null);
            jFrame.setSize(350, 250);
            jFrame.setVisible(true);

            jButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selectedDestination = "You selected " + jComboBox.getItemAt(jComboBox.getSelectedIndex());
                    jLabel.setText(selectedDestination);
                }
            });

        }
    }

 // Implementation of single linked list
 public class LinkedList {
  
     Node head; // head of list
  
     // Linked list Node
     static class Node {
  
         int data;
         Node next;
  
         // Constructor
         Node(int d)
         {
             data = d;
             next = null;
         }
     }
  
     // Method to insert new node
     public static LinkedList insert(LinkedList list,
                                     int data)
     {
         // Create a new node with given data
         Node new_node = new Node(data);
         new_node.next = null;
  
         // If the Linked List is empty, then make the new node as head
         if (list.head == null) {
             list.head = new_node;
         }
         else {
           
             Node last = list.head;
             while (last.next != null) {
                 last = last.next;
             }
  
             // Insert the new_node at last node
             last.next = new_node;
         }
  
         // Return the list by head
         return list;
     }
  
     // Method to print the LinkedList - travere
     public static void printList(LinkedList list)
     {
         Node currNode = list.head;
  
         System.out.print("\nLinkedList: ");
  
         // Traverse through LinkedList
         while (currNode != null) {
             // Print the data at current node
             System.out.print(currNode.data + " ");
  
             // Go to next node
             currNode = currNode.next;
         }
         System.out.println("\n");
     }
  
     // Method to delete a node
     public static LinkedList deleteByKey(LinkedList list,
                                          int key)
     {
         // Store head node
         Node currNode = list.head, prev = null;
  
         // If head node itself holds the key to be deleted
  
         if (currNode != null && currNode.data == key) {
             list.head = currNode.next; // Changed head
  
             // Display message
             System.out.println(key + " found and deleted");
  
             // Return the updated List
             return list;
         }
 
         // If the key is somewhere other than at head, search for the key to be deleted,

         while (currNode != null && currNode.data != key) {
             // If currNode does not hold key, continue to next
             prev = currNode;
             currNode = currNode.next;
         }
  
         // If the key was present, it should be at currNode
         if (currNode != null) {
             prev.next = currNode.next;
  
             // Display message
             System.out.println(key + " found and deleted");
         }

         // If key was not present in linked list, currNode should be null
         if (currNode == null) {
             // Display message
             System.out.println(key + " not found");
         }
  
         // return the List
         return list;
     }
  
     //Delete a node in the LinkedList by POSITION
     public static LinkedList
     deleteAtPosition(LinkedList list, int index)
     {
         // Store head node
         Node currNode = list.head, prev = null;

         // If index is 0, then head node itself is to be deleted
  
         if (index == 0 && currNode != null) {
             list.head = currNode.next; // Changed head
  
             // Display message
             System.out.println(
                 index + " position element deleted");
  
             // Return the updated List
             return list;
         }

         // If the index is greater than 0 but less than the size of LinkedList
         int counter = 0;
         while (currNode != null) {
  
             if (counter == index) {
                 prev.next = currNode.next;
  
                 // Display message
                 System.out.println(
                     index + " position element deleted");
                 break;
             }
             else {
                 // If current position is not the index, continue to next node
                 prev = currNode;
                 currNode = currNode.next;
                 counter++;
             }
         }
  // The index is greater than the size of the LinkedList
         if (currNode == null) {
             // Display message
             System.out.println(
                 index + " position element not found");
         }
  
         // return the List
         return list;
     }
  
     }
 
    
    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}