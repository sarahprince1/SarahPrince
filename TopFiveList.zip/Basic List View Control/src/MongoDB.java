import com.mongodb.ErrorCategory;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class MongoDB {

    public static void main(String[] args) {
        try {
            // Connect to MongoDB Server on localhost
            final MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
            // Connect to Database "location"
            final MongoDatabase database = mongoClient.getDatabase("location");
            System.out.println("Successful database connection established. \n");
            

            //Insert a document into the "location" collection.
            MongoCollection<Document> collection = database.getCollection("location");

            // Delete the collection and start fresh
            collection.drop();

            Document lasVegas = new Document();
            Document newYorkCity= new Document();

            lasVegas.append("_id", 1)
                    .append("location", "Las Vegas")
                    .append("country", new Document("countryName", "USA"));

            newYorkCity.append("_id", 2)
                    .append("location", "New York City")
                    .append("country", new Document("countryName", "USA"));

            try {
                collection.insertOne(lasVegas);
                collection.insertOne(newYorkCity);
                System.out.println("Successfully inserted documents. \n");
            } catch (MongoWriteException mwe) {
                if (mwe.getError().getCategory().equals(ErrorCategory.DUPLICATE_KEY)) {
                    System.out.println("Document with that id already exists");
                }
            }

            // Data on collection
            System.out.println("Collection size: " + collection.count() + " documents. \n");

            // Create and insert multiple documents
            List<Document> documents = new ArrayList<Document>();
            for (int i = 3; i < 51; i++) {
                documents.add(new Document ("_id", i)
                        .append("location", "")
                        .append("country", "")
                );
            }
            collection.insertMany(documents);

            // Basic data on collection
            System.out.println("Collection size: " + collection.count() + " documents. \n");

            // Update a document
            Document third = collection.find(Filters.eq("_id", 3)).first();
            System.out.println("Original third document:");
            System.out.println(third.toJson());

            collection.updateOne(new Document("_id", 3),
                    new Document("$set", new Document("location", "London")
                            .append("country", new Document("countryName", "England")
            )));

            System.out.println("\nUpdated third document:");
            Document London = collection.find(Filters.eq("_id", 3)).first();
            System.out.println(London.toJson());

            // Find and print documents in the collection
            System.out.println("Print the documents.");

            MongoCursor<Document> cursor = collection.find().iterator();
            try {
                while (cursor.hasNext()) {
                    System.out.println(cursor.next().toJson());
                }

            } finally {
                cursor.close();
            }

            //Delete data (as of now, there are 5 locations)
            System.out.println("\nDelete documents with an id greater than or equal to 6.");
            collection.deleteMany(Filters.gte("_id", 6));

            // Find and print ALL documents in the collection
            System.out.println("\nPrint all documents.");

            MongoCursor<Document> cursor2 = collection.find().iterator();
            try {
                while (cursor2.hasNext()) {
                    System.out.println(cursor2.next().toJson());
                }

            } finally {
                cursor2.close();
            }

        } catch (Exception exception) {
            System.err.println(exception.getClass().getName() + ": " + exception.getMessage());
        }
    }
}